﻿using System;

namespace cobwebsProject
{
    class Program
    {
        static void Main(string[] args)
        {
            cobwebsProject.BL.ManagerIO.GetPlayersData();
            Players.PlayersGroup.ManageGuessesGame();
        }
    }
}
