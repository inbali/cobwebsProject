﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace cobwebsProject.Players
{
    public class PlayersGroup
    {
        public int playersCount;
        private static List<BasePlayer> allPlayers;

        PlayersGroup() 
        {
            this.playersCount = 0;
            allPlayers = new List<BasePlayer>();
        }
        private static readonly object plock = new object();
        private static PlayersGroup instance = null;
        public static PlayersGroup Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (plock)
                    {
                        if (instance == null)
                        {
                            instance = new PlayersGroup();
                        }
                    }
                }
                return instance;
            }
        }

        public void AddPlayer(string name, int playerNum, int type)
        {
            BasePlayer player;
            Enums.PlayersType enmVal = (Enums.PlayersType)type;
            switch (enmVal) 
            {
                case Enums.PlayersType.RandomPlayer:
                    player = new RandomPlayer(name, playerNum, type);
                    allPlayers.Add(player);
                    break;
                case Enums.PlayersType.MemoryPlayer:
                    player = new MemoryPlayer(name, playerNum, type);
                    allPlayers.Add(player);
                    break;
                case Enums.PlayersType.ThoroughPlayer:
                    player = new ThoroughPlayer(name, playerNum, type);
                    allPlayers.Add(player);
                    break;
                case Enums.PlayersType.CheaterPlayer:
                    player = new CheaterPlayer(name, playerNum, type);
                    allPlayers.Add(player);
                    break;
                case Enums.PlayersType.ThroroughCheaterPlayer:
                    player = new CheaterThoroughPlayer(name, playerNum, type);
                    allPlayers.Add(player);
                    break;
            }
        }

        public static void ManageGuessesGame() 
        {
            if (allPlayers.Count >= ProgramParams.MinimalPlayersCount)
            {
                bool gameEnded = false;
                BasePlayer[] players = allPlayers.ToArray();
                do {
                    int allPlayersGuesses = allPlayers.Sum(a => a.totalAmountGuesses);
                    if (allPlayersGuesses >= 100)
                    {
                        cobwebsProject.BL.ManagerIO.PrintsWhenTooManyAttempts();
                    }

                    for (int i = 0; i < players.Length; i++)
                    {
                        int guess = players[i].GuessWeight();
                        if (guess == ProgramParams.BasketWeight)
                        {
                            cobwebsProject.BL.ManagerIO.PrintsWinnerData(players[i].name, players[i].totalAmountGuesses);
                            gameEnded = true;
                            break;
                        }
                    }
                } while (!gameEnded);
            }
        }

        public static string GetDataOfBestGuessesPlayer() 
        {
            string str = string.Empty;
            int currDelta = -1;

            foreach (BasePlayer player in allPlayers)
            {
                int plDelta = Math.Abs(ProgramParams.BasketWeight - player.bestGuess);
                if (currDelta == -1 || plDelta < currDelta)
                {
                    currDelta = plDelta;
                    str = string.Format("Best guess belongs to player: {0}, and his guess was: {1}", player.name, player.bestGuess);
                }
            }

            return str;
        }
    }
}
