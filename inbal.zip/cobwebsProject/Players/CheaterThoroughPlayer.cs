﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class CheaterThoroughPlayer: BasePlayer
    {
        private int lastSelectedIndex = -1;
        public CheaterThoroughPlayer(string plName, int plNum, int plType) : base(plName, plNum, plType)
        { 
        }

        public override int GuessWeight()
        {
            lastSelectedIndex++;
            int guessedValue = ManagedUnselectedNmbers.SetLowestAsSelected(lastSelectedIndex);
            this.totalAmountGuesses++;

            if (this.bestGuess == -1)
            {
                this.bestGuess = guessedValue;
            }
            else
            {
                int delta1 = Math.Abs(ProgramParams.BasketWeight - guessedValue);
                int delta2 = Math.Abs(ProgramParams.BasketWeight - this.bestGuess);

                if (delta1 < delta2)
                {
                    this.bestGuess = guessedValue;
                }
            }

            return guessedValue;
        }
    }
}
