﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class ManagedUnselectedNmbers
    {
        private static int maxRelevantIndex;
        private static int arrayLen = (ProgramParams.maximalBasketWeight - ProgramParams.minimalBasketWeight) + 1;
        private static int[] numbersToGuess = new int[arrayLen];
        private static readonly object plock = new object();

        public ManagedUnselectedNmbers() 
        {
            maxRelevantIndex = numbersToGuess.Length - 1;
            for (int index = 0; index < ProgramParams.maximalBasketWeight; index++)
            {
                numbersToGuess[index] = index + ProgramParams.minimalBasketWeight;
            }
        }

        private static void init() 
        {
            if (maxRelevantIndex <= 0) 
            {
                maxRelevantIndex = numbersToGuess.Length - 1;
                for (int index = 0; index < arrayLen; index++)
                {
                    numbersToGuess[index] = index + ProgramParams.minimalBasketWeight;
                }
            }
        }

        public static int SetLowestAsSelected(int index) 
        {
            init();
            int guessedNumber;

            lock (plock)
            {
                guessedNumber = numbersToGuess[index];
                numbersToGuess[0] = numbersToGuess[maxRelevantIndex];
                maxRelevantIndex--;
            }
            return guessedNumber;
        }
        public static int SetRandomAsSelected() 
        {
            init();
            int guessedValue;
            lock (plock)
            {
                Random r = new Random();
                int guessedIndex = r.Next(0, maxRelevantIndex);
                guessedValue = numbersToGuess[guessedIndex];
                numbersToGuess[guessedIndex] = numbersToGuess[maxRelevantIndex];
                maxRelevantIndex--;
            }
            return guessedValue;
        }

        public static void SetNumberAsSelected(int number) 
        {
            init();
            lock (plock)
            {
                Random r = new Random();
                int guessedIndex = (number - ProgramParams.minimalBasketWeight);
                numbersToGuess[guessedIndex] = numbersToGuess[maxRelevantIndex];
                maxRelevantIndex--;
            }
        }
    }
}
