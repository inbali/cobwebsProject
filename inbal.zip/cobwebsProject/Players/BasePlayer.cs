﻿using System;
using System.Collections.Generic;
using System.Text;
using cobwebsProject;

namespace cobwebsProject.Players
{
    abstract class BasePlayer
    {
        public string name;
        public int totalAmountGuesses;
        public int bestGuess;
        int participentNumber;
        Enums.PlayersType playerType;

        public BasePlayer(string plName, int plNum, int plType)
        {
            this.name = plName;
            this.totalAmountGuesses = 0;
            this.bestGuess = -1;
            this.participentNumber = plNum;
            this.playerType = (Enums.PlayersType)plType;
        }

        protected void SetNumberAsSelected(int number)
        {
            this.totalAmountGuesses++;
            ManagedUnselectedNmbers.SetNumberAsSelected(number);

            if (this.bestGuess == -1)
            {
                this.bestGuess = number;
            }
            else 
            {
                int delta1 = Math.Abs(ProgramParams.BasketWeight - number);
                int delta2 = Math.Abs(ProgramParams.BasketWeight - this.bestGuess);

                if (delta1 < delta2)
                {
                    this.bestGuess = number;
                }
            }
        }

        public abstract int GuessWeight();
    }
}
