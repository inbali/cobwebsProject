﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class MemoryPlayer:BasePlayer
    {
        private Dictionary<int, int> values = new Dictionary<int, int>();
        public MemoryPlayer(string plName, int plNum, int plType) : base(plName, plNum, plType)
        {
            for (int index = 0; index < 100; index++)
            {
                values.Add(index, (40 + index));
            }
        }

        public override int GuessWeight()
        {
            Random r = new Random();
            int randomKey = r.Next(0, values.Count - 1);
            int selectedValue;
            values.TryGetValue(randomKey, out selectedValue);
            if (randomKey < values.Count - 1)
            {
                values[randomKey] = values[values.Count - 1];
            }
            values.Remove(values.Count - 1);

            SetNumberAsSelected(selectedValue);

            return selectedValue;
        }
    }
}
