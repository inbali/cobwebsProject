﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class RandomPlayer:BasePlayer
    {

        public RandomPlayer(string plName, int plNum, int plType) : base(plName, plNum, plType)
        {
        }

        public override int GuessWeight()
        {
            Random r = new Random();
            int randomValue = r.Next(40, 140);

            SetNumberAsSelected(randomValue);

            return randomValue;
        }
    }
}
