﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class ThoroughPlayer:BasePlayer
    {
        private int nextNumberToGuess;
        public ThoroughPlayer(string plName, int plNum, int plType) : base(plName, plNum, plType)
        {
            this.nextNumberToGuess = 40;
        }

        public override int GuessWeight()
        {
            int returnNumber = this.nextNumberToGuess;
            if(this.nextNumberToGuess < 140)
                this.nextNumberToGuess++;

            SetNumberAsSelected(returnNumber);
            return returnNumber;
        }
    }
}
