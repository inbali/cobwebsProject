﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.Players
{
    class CheaterPlayer : BasePlayer
    {
        public CheaterPlayer(string plName, int plNum, int plType) : base(plName, plNum, plType)
        { 
        }

        public override int GuessWeight()
        {
            int guessNumber = ManagedUnselectedNmbers.SetRandomAsSelected();
            this.totalAmountGuesses++;

            if (this.bestGuess == -1)
            {
                this.bestGuess = guessNumber;
            }
            else
            {
                int delta1 = Math.Abs(ProgramParams.BasketWeight - guessNumber);
                int delta2 = Math.Abs(ProgramParams.BasketWeight - this.bestGuess);

                if (delta1 < delta2)
                {
                    this.bestGuess = guessNumber;
                }
            }

            return guessNumber;
        }
    }
}
