﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.BL
{
    static class ManagerIO
    {
        public static void GetPlayersData() 
        {
            getPlayersCount();
            getPlayersData();
            printsPreGameData();
        }


        private static void getPlayersCount()
        {
            bool isOK = false;
            int inputNumber = 0;

            do
            {
                Console.Write("Please enter players number (numeric between 2 and 8):");
                string result = Console.ReadLine();
                isOK = result.IsNumeric(out inputNumber);
            } while (inputNumber < 2 || inputNumber > 8);
            Players.PlayersGroup.Instance.playersCount =  inputNumber;
        }

        private static void getPlayersData() 
        {
            int numType;
            int nextPlayerInput = 1;
            while (nextPlayerInput <= Players.PlayersGroup.Instance.playersCount)
            {
                string name, type;
                string msg = string.Format("Enter name for player {0}: ", nextPlayerInput);
                Console.Write(msg);
                name = Console.ReadLine();

                do
                {
                    msg = string.Format(@"Choose player type: {0}Choose 1 for random player {0}choose 2 for memory player {0}choose 3 for thorough player {0}choose 4 for cheater player {0}choose 5 for thorogh cheater player:", Environment.NewLine);
                    Console.Write(msg);
                    type = Console.ReadLine();
                    bool isValidInput = type.IsNumeric(out numType);
                } while (numType <= 0);
                Players.PlayersGroup.Instance.AddPlayer(name, nextPlayerInput, numType);
                nextPlayerInput++;
            }
        }

        private static void printsPreGameData() 
        {
            string msg = string.Format("The basket weight is: {0}", ProgramParams.BasketWeight);
            Console.WriteLine(msg);
            Console.WriteLine("The game begins now.");
        }

        public static void PrintsWinnerData(string playerName, int totalAttempts) 
        {
            string msg = string.Format("The winner is: {0} with total attempts of: {1}. {2} The game is over.", playerName, totalAttempts, Environment.NewLine);
            Console.WriteLine(msg);
        }

        public static void PrintsWhenTooManyAttempts() 
        {
            string bestGuessTxt = Players.PlayersGroup.GetDataOfBestGuessesPlayer();
            Console.WriteLine("There were too many players attempts. Game is over.");
            Console.WriteLine(bestGuessTxt);
        }
    }
}
