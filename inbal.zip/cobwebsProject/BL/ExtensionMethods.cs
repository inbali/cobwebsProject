﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject.BL
{
    public static class ExtensionMethods
    {
        public static bool IsNumeric(this string str, out int value)
        {
            bool result = Int32.TryParse(str, out value);
            if (result == false)
            {
                value = -1;
            }

            return result;
        }
    }
}
