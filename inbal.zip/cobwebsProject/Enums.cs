﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject
{
    class Enums
    {
        public enum PlayersType
        {
            RandomPlayer,
            MemoryPlayer,
            ThoroughPlayer,
            CheaterPlayer,
            ThroroughCheaterPlayer
        }
    }
}
