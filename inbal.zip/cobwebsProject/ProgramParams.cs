﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cobwebsProject
{
    static class ProgramParams
    {
        public static int MinimalPlayersCount { get { return 2; } }
        public static int MaximalPlayersCount { get { return 8; } }
        public static int minimalBasketWeight { get {return 40; } }
        public static int maximalBasketWeight { get { return 140; }}

        private static int basketWeight = -1;
        public static int BasketWeight 
        { 
            get{
                if (basketWeight <= 0)
                {
                    Random r = new Random();
                    basketWeight = r.Next(minimalBasketWeight, maximalBasketWeight);
                }
                return basketWeight;
            } 
        }


        /*public ProgramParams() 
        {
            MinimalPlayersCount = 2;
            MaximalPlayersCount = 8;

            minimalBasketWeight = 40;
            maximalBasketWeight = 140;

            Random r = new Random();
            BasketWeight = r.Next(minimalBasketWeight, maximalBasketWeight);
        }*/
    }
}
